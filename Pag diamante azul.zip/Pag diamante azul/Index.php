<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diamante Azul</title>
    <link rel="stylesheet" href="../Styles/Estilo_index.css">
</head>
<body>
    <?php include 'C:/xampp/htdocs/Pag diamante azul/Barra Navegacion/Barra.html'; ?>

    <main class="contenido">
        <!-- Sección bienvenida -->
        <section class="bienvenida">
            <h1>Bienvenido a Diamante Azul</h1>
            <p>Somos una empresa dedicada a brindar soluciones modernas con la mejor calidad. Explora nuestras imágenes y conoce más sobre nosotros.</p>
        </section>

        <!-- Carrusel -->
        <section class="carrusel">
            <div class="slides">
                <img src="imagenes/img1.jpg" alt="Imagen 1">
                <img src="imagenes/img2.jpg" alt="Imagen 2">
                <img src="imagenes/img3.jpg" alt="Imagen 3">
            </div>
            <button class="prev">&#10094;</button>
            <button class="next">&#10095;</button>
        </section>

        <!-- Galería -->
        <section class="galeria">
            <img src="imagenes/img4.jpg" alt="Extra 1">
            <img src="imagenes/img5.jpg" alt="Extra 2">
            <img src="imagenes/img6.jpg" alt="Extra 3">
        </section>

        <!-- Texto tipo plantilla corporativa -->
        <section class="info">
            <h2>Sobre Nosotros</h2>
            <p>
                En Diamante Azul trabajamos con pasión y compromiso. Nuestro equipo está conformado por profesionales
                que buscan la excelencia en cada detalle. Nos enfocamos en innovación, confianza y calidad para nuestros clientes.
            </p>
        </section>

        <section class="servicios">
            <h2>Nuestros Servicios</h2>
            <ul>
                <li>✔️ Consultoría personalizada</li>
                <li>✔️ Soluciones digitales a la medida</li>
                <li>✔️ Soporte técnico especializado</li>
                <li>✔️ Capacitación y asesoría continua</li>
            </ul>
        </section>

        <section class="contacto">
            <h2>Contáctanos</h2>
            <p>
                📍 Dirección: Calle Principal #123, Bogotá, Colombia <br>
                📞 Teléfono: +57 300 123 4567 <br>
                ✉️ Correo: contacto@diamanteazul.com
            </p>
        </section>
    </main>

    <script src="carrusel.js"></script>
</body>
</html>
