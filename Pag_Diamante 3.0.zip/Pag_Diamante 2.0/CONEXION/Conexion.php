<?php

class CONECTAR
{
    private $servidor = "localhost";
    private $usuario = "root";
    private $basedatos = "Diamante_Azul";
    private $password = "";

    public function conexion() 
    {
        $conexion = mysqli_connect($this->servidor, $this->usuario, $this->password, $this->basedatos);
        if (!$conexion) {
            die("Error en la conexión: " . mysqli_connect_error());
        }
        mysqli_set_charset($conexion, "utf8");
        return $conexion;
    }
}
?>