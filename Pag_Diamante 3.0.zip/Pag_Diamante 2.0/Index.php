
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://public-frontend-cos.metadl.com/mgx/img/favicon.png" type="image/png">
    <title>Diamante Azul - Joyería Premium</title>
    <link rel="stylesheet" href="Estilos/style.css">
    <link rel="stylesheet" href="Estilos/Estilo_Index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <?php include 'Barra Navegacion/Barra.html'; ?>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-background">
            <div class="hero-overlay"></div>
        </div>
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">
                    <span class="diamond-icon">💎</span>
                    Diamante Azul
                </h1>
                <p class="hero-subtitle">Elegancia y Distinción en Cada Joya</p>
                <p class="hero-description">
                    Descubre nuestra exclusiva colección de joyas premium, 
                    donde cada pieza cuenta una historia única de belleza y sofisticación.
                </p>
                <div class="hero-buttons">
                    <a href="#productos" class="btn-primary">
                        <i class="fa-solid fa-gem"></i>
                        Ver Colección
                    </a>
                    <a href="#contacto" class="btn-secondary">
                        <i class="fa-solid fa-phone"></i>
                        Contactar
                    </a>
                </div>
            </div>
            <div class="hero-image">
                <div class="floating-gems">
                    <div class="gem gem-1">💎</div>
                    <div class="gem gem-2">💍</div>
                    <div class="gem gem-3">✨</div>
                    <div class="gem gem-4">💎</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <div class="section-header">
                <h2>¿Por qué elegir Diamante Azul?</h2>
                <p>Calidad excepcional y servicio personalizado</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fa-solid fa-certificate"></i>
                    </div>
                    <h3>Calidad Certificada</h3>
                    <p>Todas nuestras joyas cuentan con certificados de autenticidad y calidad internacional.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fa-solid fa-palette"></i>
                    </div>
                    <h3>Diseños Únicos</h3>
                    <p>Creaciones exclusivas diseñadas por nuestros expertos artesanos con años de experiencia.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <h3>Garantía de Por Vida</h3>
                    <p>Ofrecemos garantía completa y servicio de mantenimiento para todas nuestras piezas.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fa-solid fa-truck-fast"></i>
                    </div>
                    <h3>Envío Seguro</h3>
                    <p>Entrega segura y asegurada a nivel nacional con seguimiento en tiempo real.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Products Preview -->
    <section class="products-preview" id="productos">
        <div class="container">
            <div class="section-header">
                <h2>Nuestras Colecciones</h2>
                <p>Explora nuestras exclusivas líneas de joyería premium</p>
            </div>
            <div class="products-grid">
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-placeholder">
                            <i class="fa-solid fa-ring"></i>
                        </div>
                        <div class="product-overlay">
                            <button class="btn-view">Ver Detalles</button>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>Anillos de Compromiso</h3>
                        <p>Simboliza tu amor eterno con nuestros exclusivos anillos de diamante.</p>
                        <span class="product-price">Desde $2,500</span>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-placeholder">
                            <i class="fa-solid fa-gem"></i>
                        </div>
                        <div class="product-overlay">
                            <button class="btn-view">Ver Detalles</button>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>Collares Premium</h3>
                        <p>Elegantes collares que realzan tu belleza natural con estilo único.</p>
                        <span class="product-price">Desde $1,800</span>
                    </div>
                </div>
                <div class="product-card">
                    <div class="product-image">
                        <div class="product-placeholder">
                            <i class="fa-solid fa-ear-listen"></i>
                        </div>
                        <div class="product-overlay">
                            <button class="btn-view">Ver Detalles</button>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>Aretes de Lujo</h3>
                        <p>Sofisticados aretes que complementan perfectamente cualquier ocasión.</p>
                        <span class="product-price">Desde $950</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials">
        <div class="container">
            <div class="section-header">
                <h2>Lo que dicen nuestros clientes</h2>
                <p>Experiencias reales de clientes satisfechos</p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                        <p>"La calidad es excepcional y el servicio al cliente es incomparable. Mi anillo de compromiso es perfecto."</p>
                        <div class="testimonial-author">
                            <strong>María González</strong>
                            <span>Cliente Premium</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                        <p>"Diamante Azul superó todas mis expectativas. El diseño personalizado quedó espectacular."</p>
                        <div class="testimonial-author">
                            <strong>Carlos Mendoza</strong>
                            <span>Cliente VIP</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-content">
                        <div class="stars">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                        </div>
                        <p>"Excelente atención y productos de la más alta calidad. Definitivamente recomiendo Diamante Azul."</p>
                        <div class="testimonial-author">
                            <strong>Ana Rodríguez</strong>
                            <span>Cliente Frecuente</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contacto">
        <div class="container">
            <div class="contact-content">
                <div class="contact-info">
                    <h2>Contáctanos</h2>
                    <p>Estamos aquí para ayudarte a encontrar la joya perfecta</p>
                    <div class="contact-details">
                        <div class="contact-item">
                            <i class="fa-solid fa-location-dot"></i>
                            <div>
                                <strong>Dirección</strong>
                                <p>Av. Principal 123, Centro Comercial Premium</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <i class="fa-solid fa-phone"></i>
                            <div>
                                <strong>Teléfono</strong>
                                <p>+57 (1) 234-5678</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <i class="fa-solid fa-envelope"></i>
                            <div>
                                <strong>Email</strong>
                                <p>info@diamanteazul.com</p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <i class="fa-solid fa-clock"></i>
                            <div>
                                <strong>Horarios</strong>
                                <p>Lun - Sáb: 9:00 AM - 7:00 PM</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="contact-form">
                    <form class="form">
                        <div class="form-group">
                            <input type="text" placeholder="Nombre completo" required>
                        </div>
                        <div class="form-group">
                            <input type="email" placeholder="Correo electrónico" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" placeholder="Teléfono">
                        </div>
                        <div class="form-group">
                            <textarea placeholder="Mensaje" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn-primary">
                            <i class="fa-solid fa-paper-plane"></i>
                            Enviar Mensaje
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>💎 Diamante Azul</h3>
                    <p>Tu joyería de confianza desde 1995. Calidad, elegancia y distinción en cada pieza.</p>
                    <div class="social-links">
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Productos</h4>
                    <ul>
                        <li><a href="#">Anillos</a></li>
                        <li><a href="#">Collares</a></li>
                        <li><a href="#">Aretes</a></li>
                        <li><a href="#">Pulseras</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Servicios</h4>
                    <ul>
                        <li><a href="#">Diseño Personalizado</a></li>
                        <li><a href="#">Reparaciones</a></li>
                        <li><a href="#">Certificación</a></li>
                        <li><a href="#">Garantía</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Información</h4>
                    <ul>
                        <li><a href="#">Sobre Nosotros</a></li>
                        <li><a href="#">Términos y Condiciones</a></li>
                        <li><a href="#">Política de Privacidad</a></li>
                        <li><a href="#">Contacto</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Diamante Azul. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <script src="Barra Navegacion/script.js"></script>
</body>
</html>