<?php
session_start();
require_once '../CONEXION/Conexion.php';

if ($_POST) {
    $nombre = trim($_POST['fullname']);
    $documento = trim($_POST['document']);
    $direccion = trim($_POST['address']);
    $telefono = trim($_POST['phone']);
    $password = trim($_POST['password']);
    $usuario = trim($_POST['username']);
    
    // Validar campos vacíos
    if (empty($nombre) || empty($documento) || empty($direccion) || empty($telefono) || empty($password) || empty($usuario)) {
        header("Location: Register.php?error=campos_vacios");
        exit();
    }
    
    // Validar que documento sea numérico (bigint en BD)
    if (!is_numeric($documento)) {
        header("Location: Register.php?error=documento_invalido");
        exit();
    }
    
    // Validar que teléfono sea numérico (bigint en BD)
    if (!is_numeric($telefono)) {
        header("Location: Register.php?error=telefono_invalido");
        exit();
    }
    
    $conectar = new CONECTAR();
    $conexion = $conectar->conexion();
    
    // Verificar si el usuario ya existe
    $sql_check = "SELECT * FROM cargo WHERE nombreusu = ?";
    $stmt_check = mysqli_prepare($conexion, $sql_check);
    mysqli_stmt_bind_param($stmt_check, "s", $usuario);
    mysqli_stmt_execute($stmt_check);
    $resultado_check = mysqli_stmt_get_result($stmt_check);
    
    if (mysqli_num_rows($resultado_check) > 0) {
        header("Location: Register.php?error=usuario_existe");
        exit();
    }
    
    // Verificar si el documento ya existe (TipoDocumento es bigint)
    $sql_doc = "SELECT * FROM Cliente WHERE TipoDocumento = ?";
    $stmt_doc = mysqli_prepare($conexion, $sql_doc);
    mysqli_stmt_bind_param($stmt_doc, "i", $documento); // "i" para integer/bigint
    mysqli_stmt_execute($stmt_doc);
    $resultado_doc = mysqli_stmt_get_result($stmt_doc);
    
    if (mysqli_num_rows($resultado_doc) > 0) {
        header("Location: Register.php?error=documento_existe");
        exit();
    }
    
    // Iniciar transacción
    mysqli_begin_transaction($conexion);
    
    try {
        // Obtener el próximo ID para Cliente
        $sql_max_id = "SELECT MAX(idCliente) as max_id FROM Cliente";
        $resultado_max = mysqli_query($conexion, $sql_max_id);
        $fila_max = mysqli_fetch_assoc($resultado_max);
        $nuevo_id = ($fila_max['max_id'] ?? 0) + 1;
        
        // Insertar en tabla Cliente (TipoDocumento y telefonocliente son bigint)
        $sql_cliente = "INSERT INTO Cliente (idCliente, nomCliente, TipoDocumento, Direccion, telefonocliente) VALUES (?, ?, ?, ?, ?)";
        $stmt_cliente = mysqli_prepare($conexion, $sql_cliente);
        mysqli_stmt_bind_param($stmt_cliente, "isisi", $nuevo_id, $nombre, $documento, $direccion, $telefono);
        
        if (!mysqli_stmt_execute($stmt_cliente)) {
            throw new Exception("Error al insertar cliente: " . mysqli_error($conexion));
        }
        
        // Insertar en tabla cargo
        $rol = 0; // Cliente
        $sql_cargo = "INSERT INTO cargo (nombreusu, contra, rol) VALUES (?, ?, ?)";
        $stmt_cargo = mysqli_prepare($conexion, $sql_cargo);
        mysqli_stmt_bind_param($stmt_cargo, "ssi", $usuario, $password, $rol);
        
        if (!mysqli_stmt_execute($stmt_cargo)) {
            throw new Exception("Error al crear usuario: " . mysqli_error($conexion));
        }
        
        // Confirmar transacción
        mysqli_commit($conexion);
        
        // Configurar sesión
        $cargo_id = mysqli_insert_id($conexion);
        $_SESSION['usuario_id'] = $cargo_id;
        $_SESSION['usuario_nombre'] = $usuario;
        $_SESSION['usuario_rol'] = 0;
        $_SESSION['cliente_id'] = $nuevo_id;
        $_SESSION['cliente_nombre'] = $nombre;
        $_SESSION['loggedin'] = true;
        
        header("Location: ../Dashboard/cliente_dashboard.php?registro=exitoso");
        exit();
        
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        mysqli_rollback($conexion);
        error_log("Error en registro: " . $e->getMessage());
        header("Location: Register.php?error=error_servidor");
        exit();
    }
    
    mysqli_close($conexion);
} else {
    header("Location: Register.php");
    exit();
}
?>