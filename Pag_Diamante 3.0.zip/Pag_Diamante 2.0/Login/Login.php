<?php
session_start();

// Si ya está logueado, redirigir según rol
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    if ($_SESSION['usuario_rol'] == 1) {
        header("Location: ../Dashboard/empleado_dashboard.php");
    } else {
        header("Location: ../Dashboard/cliente_dashboard.php");
    }
    exit();
}

// Manejar mensajes de error
$error_message = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'campos_vacios':
            $error_message = 'Por favor complete todos los campos';
            break;
        case 'credenciales_invalidas':
            $error_message = 'Usuario o contraseña incorrectos';
            break;
        case 'usuario_no_existe':
            $error_message = 'El usuario no existe';
            break;
        case 'sesion_requerida':
            $error_message = 'Debe iniciar sesión para acceder';
            break;
    }
}

$success_message = '';
if (isset($_GET['logout']) && $_GET['logout'] === 'exitoso') {
    $success_message = 'Sesión cerrada correctamente';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://public-frontend-cos.metadl.com/mgx/img/favicon.png" type="image/png">
    <title>Iniciar Sesión - Diamante Azul</title>
    <link rel="stylesheet" href="../Estilos/style.css">
    <link rel="stylesheet" href="../Estilos/forms.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .alert {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 14px;
        }
        .alert-error {
            background-color: #fee;
            color: #c53030;
            border: 1px solid #fed7d7;
        }
        .alert-success {
            background-color: #f0fff4;
            color: #38a169;
            border: 1px solid #c6f6d5;
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo">💎 Diamante Azul</div>
        
        <nav class="nav">
            <a href="../Index.php" class="nav-link">Inicio</a>
            <a href="#" class="nav-link">Productos</a>
            <a href="#" class="nav-link">Servicios</a>
            <a href="#" class="nav-link">Contacto</a>
        </nav>
        
        <div class="nav-actions">
            <button class="theme-btn" id="themeToggle">🌙</button>
            
            <div class="user-menu">
                <button id="userBtn" class="user-btn">
                    <i class="fa-solid fa-user"></i>
                </button>
                <div class="user-dropdown" id="userDropdown">
                    <a href="Login.php" class="active-link">Iniciar sesión</a>
                    <a href="Register.php">Registrarse</a>
                </div>
            </div>
        </div>
    </header>

    <main class="form-container">
        <div class="form-wrapper">
            <div class="form-header">
                <div class="form-icon">
                    <i class="fa-solid fa-gem"></i>
                </div>
                <h1>Iniciar Sesión</h1>
                <p>Bienvenido de vuelta a Diamante Azul</p>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <i class="fa-solid fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert alert-success">
                    <i class="fa-solid fa-check-circle"></i>
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <form class="auth-form" method="post" action="procesar_login.php">
                <div class="input-group">
                    <label for="email">
                        <i class="fa-solid fa-user"></i>
                        Usuario
                    </label>
                    <input type="text" id="email" name="email" placeholder="Ingresa tu usuario" required>
                </div>

                <div class="input-group">
                    <label for="password">
                        <i class="fa-solid fa-lock"></i>
                        Contraseña
                    </label>
                    <input type="password" id="password" name="password" placeholder="Ingresa tu contraseña" required>
                </div>

                <div class="form-options">
                    <label class="checkbox-container">
                        <input type="checkbox" name="remember">
                        <span class="checkmark"></span>
                        Recordarme
                    </label>
                    <a href="#" class="forgot-link">¿Olvidaste tu contraseña?</a>
                </div>

                <button type="submit" class="form-submit-btn">
                    <i class="fa-solid fa-sign-in-alt"></i>
                    Iniciar Sesión
                </button>

                <div class="form-footer">
                    <p>¿No tienes una cuenta? <a href="Register.php" class="switch-link">Regístrate aquí</a></p>
                </div>
            </form>
        </div>
    </main>

    <script src="../Barra Navegacion/script.js"></script>
</body>
</html>