<?php
session_start();
require_once '../CONEXION/Conexion.php';

if ($_POST) {
    $usuario = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    if (empty($usuario) || empty($password)) {
        header("Location: Login.php?error=campos_vacios");
        exit();
    }
    
    $conectar = new CONECTAR();
    $conexion = $conectar->conexion();
    
    $sql = "SELECT * FROM cargo WHERE nombreusu = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "s", $usuario);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    
    if ($fila = mysqli_fetch_assoc($resultado)) {
        if ($password === $fila['contra']) {
            $_SESSION['usuario_id'] = $fila['idcargo'];
            $_SESSION['usuario_nombre'] = $fila['nombreusu'];
            $_SESSION['usuario_rol'] = $fila['rol'];
            $_SESSION['loggedin'] = true;
            
            if ($fila['rol'] == 1) {
                $sql_emp = "SELECT * FROM Empleado LIMIT 1";
                $resultado_emp = mysqli_query($conexion, $sql_emp);
                
                if ($empleado = mysqli_fetch_assoc($resultado_emp)) {
                    $_SESSION['empleado_id'] = $empleado['idEmpleado'];
                    $_SESSION['empleado_nombre'] = $empleado['NombreEmple'];
                }
                
                header("Location: ../Dashboard/empleado_dashboard.php");
            } else {
                $sql_cli = "SELECT * FROM Cliente ORDER BY idCliente DESC LIMIT 1";
                $resultado_cli = mysqli_query($conexion, $sql_cli);
                
                if ($cliente = mysqli_fetch_assoc($resultado_cli)) {
                    $_SESSION['cliente_id'] = $cliente['idCliente'];
                    $_SESSION['cliente_nombre'] = $cliente['nomCliente'];
                }
                
                header("Location: ../Dashboard/cliente_dashboard.php");
            }
            exit();
        } else {
            header("Location: Login.php?error=credenciales_invalidas");
            exit();
        }
    } else {
        header("Location: Login.php?error=usuario_no_existe");
        exit();
    }
    
    mysqli_close($conexion);
} else {
    header("Location: Login.php");
    exit();
}
?>
