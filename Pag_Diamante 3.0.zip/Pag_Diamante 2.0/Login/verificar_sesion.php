<?php
function verificar_sesion($rol_requerido = null) {
    session_start();
    
    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
        header("Location: ../Login/Login.php?error=sesion_requerida");
        exit();
    }
    
    if ($rol_requerido !== null && $_SESSION['usuario_rol'] != $rol_requerido) {
        if ($_SESSION['usuario_rol'] == 1) {
            header("Location: ../Dashboard/empleado_dashboard.php");
        } else {
            header("Location: ../Dashboard/cliente_dashboard.php");
        }
        exit();
    }
    
    return true;
}

function obtener_info_usuario() {
    return [
        'id' => $_SESSION['usuario_id'],
        'nombre' => $_SESSION['usuario_nombre'],
        'rol' => $_SESSION['usuario_rol']
    ];
}
?>
