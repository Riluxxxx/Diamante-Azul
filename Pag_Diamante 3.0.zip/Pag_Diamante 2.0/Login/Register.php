<?php
session_start();

// Si ya está logueado, redirigir según rol
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    if ($_SESSION['usuario_rol'] == 1) {
        header("Location: ../Dashboard/empleado_dashboard.php");
    } else {
        header("Location: ../Dashboard/cliente_dashboard.php");
    }
    exit();
}

// Manejar mensajes de error
$error_message = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'campos_vacios':
            $error_message = 'Por favor complete todos los campos';
            break;
        case 'usuario_existe':
            $error_message = 'El nombre de usuario ya existe';
            break;
        case 'documento_existe':
            $error_message = 'El número de documento ya está registrado';
            break;
        case 'error_servidor':
            $error_message = 'Error del servidor. Intente nuevamente';
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://public-frontend-cos.metadl.com/mgx/img/favicon.png" type="image/png">
    <title>Registrarse - Diamante Azul</title>
    <link rel="stylesheet" href="../Estilos/style.css">
    <link rel="stylesheet" href="../Estilos/forms.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .alert {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 14px;
        }
        .alert-error {
            background-color: #fee;
            color: #c53030;
            border: 1px solid #fed7d7;
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo">💎 Diamante Azul</div>
        
        <nav class="nav">
            <a href="../Index.php" class="nav-link">Inicio</a>
            <a href="#" class="nav-link">Productos</a>
            <a href="#" class="nav-link">Servicios</a>
            <a href="#" class="nav-link">Contacto</a>
        </nav>
        
        <div class="nav-actions">
            <button class="theme-btn" id="themeToggle">🌙</button>
            
            <div class="user-menu">
                <button id="userBtn" class="user-btn">
                    <i class="fa-solid fa-user"></i>
                </button>
                <div class="user-dropdown" id="userDropdown">
                    <a href="Login.php">Iniciar sesión</a>
                    <a href="Register.php" class="active-link">Registrarse</a>
                </div>
            </div>
        </div>
    </header>

    <main class="form-container">
        <div class="form-wrapper register-form">
            <div class="form-header">
                <div class="form-icon">
                    <i class="fa-solid fa-user-plus"></i>
                </div>
                <h1>Crear Cuenta</h1>
                <p>Únete a la familia Diamante Azul</p>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-error">
                    <i class="fa-solid fa-exclamation-triangle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <form class="auth-form" method="post" action="procesar_registro.php">
                <div class="input-group">
                    <label for="username">
                        <i class="fa-solid fa-at"></i>
                        Nombre de Usuario
                    </label>
                    <input type="text" id="username" name="username" placeholder="Elige un nombre de usuario único" required>
                </div>

                <div class="input-group">
                    <label for="fullname">
                        <i class="fa-solid fa-user"></i>
                        Nombre Completo
                    </label>
                    <input type="text" id="fullname" name="fullname" placeholder="Ingresa tu nombre completo" required>
                </div>

                <div class="input-group">
                    <label for="document">
                        <i class="fa-solid fa-id-card"></i>
                        Número de Documento
                    </label>
                    <input type="text" id="document" name="document" placeholder="Ingresa tu número de documento" required>
                </div>

                <div class="input-group">
                    <label for="address">
                        <i class="fa-solid fa-map-marker-alt"></i>
                        Dirección
                    </label>
                    <input type="text" id="address" name="address" placeholder="Ingresa tu dirección completa" required>
                </div>

                <div class="input-group">
                    <label for="phone">
                        <i class="fa-solid fa-phone"></i>
                        Teléfono
                    </label>
                    <input type="tel" id="phone" name="phone" placeholder="Ingresa tu número de teléfono" required>
                </div>

                <div class="input-group">
                    <label for="password">
                        <i class="fa-solid fa-lock"></i>
                        Contraseña
                    </label>
                    <input type="password" id="password" name="password" placeholder="Crea una contraseña segura" required>
                </div>

                <div class="form-options">
                    <label class="checkbox-container">
                        <input type="checkbox" name="terms" required>
                        <span class="checkmark"></span>
                        Acepto los <a href="#" class="terms-link">términos y condiciones</a>
                    </label>
                    <label class="checkbox-container">
                        <input type="checkbox" name="newsletter">
                        <span class="checkmark"></span>
                        Quiero recibir ofertas y promociones
                    </label>
                </div>

                <button type="submit" class="form-submit-btn">
                    <i class="fa-solid fa-user-plus"></i>
                    Crear Mi Cuenta
                </button>

                <div class="form-footer">
                    <p>¿Ya tienes una cuenta? <a href="Login.php" class="switch-link">Inicia sesión aquí</a></p>
                </div>
            </form>
        </div>
    </main>

    <script src="../Barra Navegacion/script.js"></script>
</body>
</html>