<?php
require_once '../Login/verificar_sesion.php';
verificar_sesion(0); // Solo clientes (rol = 0)

$usuario = obtener_info_usuario();

// Obtener información del cliente desde la base de datos
require_once '../CONEXION/Conexion.php';
$conectar = new CONECTAR();
$conexion = $conectar->conexion();

$cliente_info = null;
if (isset($_SESSION['cliente_id'])) {
    $sql = "SELECT * FROM Cliente WHERE idCliente = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $_SESSION['cliente_id']);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $cliente_info = mysqli_fetch_assoc($resultado);
}

mysqli_close($conexion);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://public-frontend-cos.metadl.com/mgx/img/favicon.png" type="image/png">
    <title>Mi Cuenta - Diamante Azul</title>
    <link rel="stylesheet" href="../Estilos/style.css">
    <link rel="stylesheet" href="../Estilos/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header class="navbar">
        <div class="logo">💎 Diamante Azul - Cliente</div>
        
        <nav class="nav">
            <a href="../Index.php" class="nav-link">Inicio</a>
            <a href="#" class="nav-link">Catálogo</a>
            <a href="#" class="nav-link">Mis Compras</a>
            <a href="#" class="nav-link">Contacto</a>
        </nav>
        
        <div class="nav-actions">
            <span>
                <i class="fa-solid fa-user"></i> <?php echo $usuario['nombre']; ?>
            </span>
            <a href="../Login/logout.php" class="logout-btn">
                <i class="fa-solid fa-sign-out-alt"></i> Salir
            </a>
        </div>
    </header>

    <main class="dashboard">
        <?php if (isset($_GET['registro']) && $_GET['registro'] === 'exitoso'): ?>
            <div class="alert-success dashboard">
                <i class="fa-solid fa-check-circle"></i>
                ¡Bienvenido a Diamante Azul! Tu cuenta ha sido creada exitosamente.
            </div>
        <?php endif; ?>

        <div class="dashboard-header">
            <h1 class="dashboard-title">
                <i class="fa-solid fa-gem"></i>
                Mi Cuenta
            </h1>
            <p class="dashboard-subtitle">
                Bienvenido, <?php echo $usuario['nombre']; ?>. Gestiona tu perfil y explora nuestros servicios exclusivos.
            </p>
        </div>

        <div class="profile-section">
            <div class="profile-card">
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="fa-solid fa-user"></i>
                    </div>
                    <div class="profile-name"><?php echo $cliente_info ? $cliente_info['nomCliente'] : $usuario['nombre']; ?></div>
                    <div class="profile-type">Cliente Premium</div>
                </div>
                
                <?php if ($cliente_info): ?>
                <ul class="profile-info">
                    <li>
                        <i class="fa-solid fa-id-card"></i>
                        <span>Documento: <?php echo $cliente_info['TipoDocumento']; ?></span>
                    </li>
                    <li>
                        <i class="fa-solid fa-map-marker-alt"></i>
                        <span><?php echo $cliente_info['Direccion']; ?></span>
                    </li>
                    <li>
                        <i class="fa-solid fa-phone"></i>
                        <span><?php echo $cliente_info['telefonocliente']; ?></span>
                    </li>
                    <li>
                        <i class="fa-solid fa-calendar"></i>
                        <span>Cliente desde 2024</span>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
            
            <div class="profile-card">
                <h3 style="margin-bottom: 20px; color: #333;">
                    <i class="fa-solid fa-chart-line"></i> Resumen de Actividad
                </h3>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                    <div style="text-align: center; padding: 20px; background: #f8f9ff; border-radius: 10px;">
                        <div style="font-size: 2rem; font-weight: bold; color: #667eea;">3</div>
                        <div style="color: #666;">Compras Realizadas</div>
                    </div>
                    <div style="text-align: center; padding: 20px; background: #f8f9ff; border-radius: 10px;">
                        <div style="font-size: 2rem; font-weight: bold; color: #667eea;">$8,450</div>
                        <div style="color: #666;">Total Invertido</div>
                    </div>
                    <div style="text-align: center; padding: 20px; background: #f8f9ff; border-radius: 10px;">
                        <div style="font-size: 2rem; font-weight: bold; color: #667eea;">1</div>
                        <div style="color: #666;">Empeño Activo</div>
                    </div>
                    <div style="text-align: center; padding: 20px; background: #f8f9ff; border-radius: 10px;">
                        <div style="font-size: 2rem; font-weight: bold; color: #667eea;">Gold</div>
                        <div style="color: #666;">Nivel de Cliente</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="services-grid">
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-shopping-bag"></i>
                </div>
                <h3 class="service-title">Explorar Catálogo</h3>
                <p class="service-description">
                    Descubre nuestra exclusiva colección de joyas premium y encuentra la pieza perfecta para ti.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-gem"></i> Ver Productos
                </a>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-history"></i>
                </div>
                <h3 class="service-title">Mis Compras</h3>
                <p class="service-description">
                    Revisa tu historial de compras, facturas y el estado de tus pedidos anteriores.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-receipt"></i> Ver Historial
                </a>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-handshake"></i>
                </div>
                <h3 class="service-title">Mis Empeños</h3>
                <p class="service-description">
                    Consulta el estado de tus empeños, fechas de vencimiento y opciones de pago.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-coins"></i> Ver Empeños
                </a>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-palette"></i>
                </div>
                <h3 class="service-title">Diseño Personalizado</h3>
                <p class="service-description">
                    Solicita un diseño único y personalizado creado especialmente para ti por nuestros expertos.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-magic"></i> Solicitar Diseño
                </a>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-tools"></i>
                </div>
                <h3 class="service-title">Servicios de Reparación</h3>
                <p class="service-description">
                    Programa mantenimiento o reparación para tus joyas con nuestro servicio especializado.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-wrench"></i> Agendar Servicio
                </a>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i class="fa-solid fa-user-edit"></i>
                </div>
                <h3 class="service-title">Actualizar Perfil</h3>
                <p class="service-description">
                    Modifica tu información personal, dirección de entrega y preferencias de contacto.
                </p>
                <a href="#" class="service-btn">
                    <i class="fa-solid fa-edit"></i> Editar Perfil
                </a>
            </div>
        </div>
    </main>

    <script src="../Barra Navegacion/script.js"></script>
</body>
</html>