<?php
require_once '../Login/verificar_sesion.php';
verificar_sesion(1); // Solo empleados (rol = 1)

$usuario = obtener_info_usuario();

// Obtener estadísticas
require_once '../CONEXION/Conexion.php';
$conectar = new CONECTAR();
$conexion = $conectar->conexion();

// Total de clientes
$sql_clientes = "SELECT COUNT(*) as total FROM Cliente";
$resultado_clientes = mysqli_query($conexion, $sql_clientes);
$total_clientes = mysqli_fetch_assoc($resultado_clientes)['total'];

// Total de productos
$sql_productos = "SELECT COUNT(*) as total FROM Producto";
$resultado_productos = mysqli_query($conexion, $sql_productos);
$total_productos = mysqli_fetch_assoc($resultado_productos)['total'];

// Total de facturas
$sql_facturas = "SELECT COUNT(*) as total FROM Factura_Venta";
$resultado_facturas = mysqli_query($conexion, $sql_facturas);
$total_facturas = mysqli_fetch_assoc($resultado_facturas)['total'];

// Total de empeños
$sql_empenos = "SELECT COUNT(*) as total FROM Empeño";
$resultado_empenos = mysqli_query($conexion, $sql_empenos);
$total_empenos = mysqli_fetch_assoc($resultado_empenos)['total'];

mysqli_close($conexion);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="https://public-frontend-cos.metadl.com/mgx/img/favicon.png" type="image/png">
    <title>Panel Empleado - Diamante Azul</title>
    <link rel="stylesheet" href="../Estilos/style.css">
    <link rel="stylesheet" href="../Estilos/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <header class="navbar">
        <div class="logo">💎 Diamante Azul - Empleado</div>
        
        <nav class="nav">
            <a href="../Index.php" class="nav-link">Inicio</a>
            <a href="#" class="nav-link">Inventario</a>
            <a href="#" class="nav-link">Ventas</a>
            <a href="#" class="nav-link">Reportes</a>
        </nav>
        
        <div class="nav-actions">
            <span>
                <i class="fa-solid fa-user-tie"></i> <?php echo $usuario['nombre']; ?>
            </span>
            <span class="admin-badge">STAFF</span>
            <a href="../Login/logout.php" class="logout-btn">
                <i class="fa-solid fa-sign-out-alt"></i> Salir
            </a>
        </div>
    </header>

    <main class="dashboard">
        <div class="dashboard-header empleado">
            <h1 class="dashboard-title">
                <i class="fa-solid fa-chart-line"></i>
                Panel de Empleado
            </h1>
            <p class="dashboard-subtitle">
                Bienvenido, <?php echo $usuario['nombre']; ?>. Gestiona las operaciones de Diamante Azul desde aquí.
            </p>
        </div>

        <div class="stats-grid">
            <div class="stat-card empleado">
                <div class="stat-icon">
                    <i class="fa-solid fa-users"></i>
                </div>
                <div class="stat-number"><?php echo $total_clientes; ?></div>
                <div class="stat-label">
                    <i class="fa-solid fa-users"></i> Clientes Registrados
                </div>
            </div>
            
            <div class="stat-card empleado">
                <div class="stat-icon">
                    <i class="fa-solid fa-gem"></i>
                </div>
                <div class="stat-number"><?php echo $total_productos; ?></div>
                <div class="stat-label">
                    <i class="fa-solid fa-gem"></i> Productos en Stock
                </div>
            </div>
            
            <div class="stat-card empleado">
                <div class="stat-icon">
                    <i class="fa-solid fa-file-invoice"></i>
                </div>
                <div class="stat-number"><?php echo $total_facturas; ?></div>
                <div class="stat-label">
                    <i class="fa-solid fa-file-invoice"></i> Facturas Generadas
                </div>
            </div>
            
            <div class="stat-card empleado">
                <div class="stat-icon">
                    <i class="fa-solid fa-handshake"></i>
                </div>
                <div class="stat-number"><?php echo $total_empenos; ?></div>
                <div class="stat-label">
                    <i class="fa-solid fa-handshake"></i> Empeños Activos
                </div>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-users"></i> Gestión de Clientes</h3>
                <p>Administra la información de los clientes registrados, consulta historiales y gestiona perfiles.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-eye"></i> Ver Clientes
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-user-plus"></i> Nuevo Cliente
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-gem"></i> Gestión de Productos</h3>
                <p>Administra el inventario, actualiza precios, añade nuevos productos y controla el stock disponible.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-boxes"></i> Ver Inventario
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-plus-circle"></i> Nuevo Producto
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-cash-register"></i> Nueva Venta</h3>
                <p>Registra una nueva venta, genera facturas y administra el proceso de facturación completo.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-shopping-cart"></i> Crear Venta
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-file-invoice-dollar"></i> Ver Facturas
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-handshake"></i> Gestión de Empeños</h3>
                <p>Administra los servicios de empeño, fechas de vencimiento, intereses y pagos de clientes.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-coins"></i> Nuevo Empeño
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-calendar-alt"></i> Ver Vencimientos
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-chart-bar"></i> Reportes y Análisis</h3>
                <p>Genera reportes detallados de ventas, inventario, análisis financiero y estadísticas del negocio.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-chart-line"></i> Reporte Ventas
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-warehouse"></i> Reporte Inventario
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-user-tie"></i> Gestión de Personal</h3>
                <p>Administra la información del personal, horarios, roles y permisos del sistema.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-users-cog"></i> Ver Empleados
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-user-plus"></i> Nuevo Empleado
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-cogs"></i> Configuración</h3>
                <p>Configuración del sistema, parámetros generales, backup de base de datos y mantenimiento.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-tools"></i> Configurar Sistema
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-database"></i> Backup BD
                </a>
            </div>
            
            <div class="dashboard-card empleado">
                <h3><i class="fa-solid fa-bell"></i> Notificaciones</h3>
                <p>Alertas del sistema, recordatorios importantes, notificaciones de vencimientos y avisos.</p>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-exclamation-triangle"></i> Ver Alertas
                </a>
                <a href="#" class="btn-dashboard empleado">
                    <i class="fa-solid fa-cog"></i> Configurar Alertas
                </a>
            </div>
        </div>
    </main>

    <script src="../Barra Navegacion/script.js"></script>
</body>
</html>