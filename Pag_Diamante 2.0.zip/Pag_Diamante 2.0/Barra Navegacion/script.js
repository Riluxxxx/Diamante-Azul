document.addEventListener('DOMContentLoaded', () => {
  const html = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');

  // MODO OSCURO
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      if (html.getAttribute('data-theme') === 'dark') {
        html.setAttribute('data-theme', 'light');
        themeToggle.textContent = '🌙';
      } else {
        html.setAttribute('data-theme', 'dark');
        themeToggle.textContent = '☀️';
      }
    });
  }

  // Elementos del login/modal
  const loginBtn = document.getElementById('loginBtn');
  const dropdownMenu = document.getElementById('dropdownMenu');
  const openLogin = document.getElementById('openLogin');
  const openRegister = document.getElementById('openRegister');
  const modal = document.getElementById('modal');
  const closeModal = document.getElementById('closeModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');

  // Manejo del dropdown
  if (loginBtn && dropdownMenu) {
    loginBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdownMenu.classList.toggle('show');
    });

    // Cerrar dropdown si se hace click fuera
    document.addEventListener('click', (e) => {
      if (!dropdownMenu.contains(e.target) && e.target !== loginBtn) {
        dropdownMenu.classList.remove('show');
      }
    });
  }

  // Función para abrir modal
  function openModal(type) {
    if (!modal) return;
    modal.classList.add('open');

    if (modalTitle) {
      modalTitle.textContent = type === 'login' ? 'Iniciar sesión' : 'Registrarse';
    }

    if (modalBody) {
      if (type === 'login') {
        modalBody.innerHTML = `
          <input type="text" placeholder="Usuario" required>
          <input type="password" placeholder="Contraseña" required>
        `;
      } else {
        modalBody.innerHTML = `
          <input type="text" placeholder="Nombre de usuario" required>
          <input type="email" placeholder="Correo electrónico" required>
          <input type="password" placeholder="Contraseña" required>
          <input type="password" placeholder="Confirmar contraseña" required>
        `;
      }
    }

    if (dropdownMenu) dropdownMenu.classList.remove('show');
  }

  if (openLogin) {
    openLogin.addEventListener('click', (e) => {
      e.preventDefault();
      openModal('login');
    });
  }

  if (openRegister) {
    openRegister.addEventListener('click', (e) => {
      e.preventDefault();
      openModal('register');
    });
  }

  // Cerrar modal
  if (closeModal && modal) {
    closeModal.addEventListener('click', () => modal.classList.remove('open'));
  }

  window.addEventListener('click', (e) => {
    if (modal && e.target === modal) {
      modal.classList.remove('open');
    }
  });
});
