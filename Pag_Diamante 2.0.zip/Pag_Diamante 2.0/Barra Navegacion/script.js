document.addEventListener('DOMContentLoaded', function() {
    // Elementos
    const themeToggle = document.getElementById('themeToggle');
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    const loginLink = document.getElementById('loginLink');
    const registerLink = document.getElementById('registerLink');
    
    // Variables para modal
    let currentModal = null;

    // ========================
    // TEMA OSCURO/CLARO
    // ========================
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            
            if (currentTheme === 'dark') {
                html.setAttribute('data-theme', 'light');
                themeToggle.textContent = '🌙';
            } else {
                html.setAttribute('data-theme', 'dark');
                themeToggle.textContent = '☀️';
            }
        });
    }

    // ========================
    // MENÚ USUARIO
    // ========================
    if (userBtn && userDropdown) {
        userBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            userDropdown.classList.toggle('show');
        });

        // Cerrar dropdown al hacer click fuera
        document.addEventListener('click', function(e) {
            if (!userBtn.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.remove('show');
            }
        });
    }

    // ========================
    // MODALES
    // ========================
    function createModal(type) {
        // Remover modal existente
        if (currentModal) {
            currentModal.remove();
        }

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title">${type === 'login' ? 'Iniciar Sesión' : 'Registrarse'}</h2>
                    <button class="modal-close">&times;</button>
                </div>
                <form class="modal-form">
                    ${type === 'login' ? `
                        <input type="text" class="form-input" placeholder="Usuario o Email" required>
                        <input type="password" class="form-input" placeholder="Contraseña" required>
                    ` : `
                        <input type="text" class="form-input" placeholder="Nombre completo" required>
                        <input type="email" class="form-input" placeholder="Email" required>
                        <input type="password" class="form-input" placeholder="Contraseña" required>
                        <input type="password" class="form-input" placeholder="Confirmar contraseña" required>
                    `}
                    <button type="submit" class="form-btn">${type === 'login' ? 'Iniciar Sesión' : 'Registrarse'}</button>
                </form>
            </div>
        `;

        document.body.appendChild(modal);
        currentModal = modal;

        // Mostrar modal
        setTimeout(() => modal.classList.add('show'), 10);

        // Cerrar modal
        const closeBtn = modal.querySelector('.modal-close');
        closeBtn.addEventListener('click', closeModal);
        
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });

        // Manejar formulario
        const form = modal.querySelector('.modal-form');
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            alert(type === 'login' ? 'Función de login aquí' : 'Función de registro aquí');
            closeModal();
        });

        // Cerrar dropdown
        userDropdown.classList.remove('show');
    }

    function closeModal() {
        if (currentModal) {
            currentModal.classList.remove('show');
            setTimeout(() => {
                if (currentModal) {
                    currentModal.remove();
                    currentModal = null;
                }
            }, 300);
        }
    }

    // Event listeners para los enlaces
    if (loginLink) {
        loginLink.addEventListener('click', function(e) {
            e.preventDefault();
            createModal('login');
        });
    }

    if (registerLink) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            createModal('register');
        });
    }

    // Cerrar modal con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && currentModal) {
            closeModal();
        }
    });
});