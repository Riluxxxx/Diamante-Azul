<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diamante Azul</title>
    <link rel="stylesheet" href="Estilos/Estilo_Index.css">
    <script src="script.js" defer></script>
</head>
<body>
    
    <?php include('Barra Navegacion/Barra.html'); ?>

    <main class="main-content">
        <section class="Main">
            <h1>Bienvenido a Diamante Azul</h1>
            <p>Una experiencia moderna en diseño web con estilo profesional.</p>
            <p> Lorem ipsum dolor sit amet consectetur, adipiscing elit porta magna gravida, pulvinar est ornare dictumst. Ultricies rhoncus senectus nisl per sapien in, parturient luctus condimentum quis risus fames habitant, congue quisque lacinia maecenas libero. Facilisi posuere sodales dictum cursus laoreet bibendum velit mi feugiat justo nunc, sagittis augue cras class netus semper cum in litora convallis.

Non tempor dis ad iaculis fusce turpis accumsan ac dapibus bibendu
        </section>
        <br>
        <br>
        <br>
        <section class="color-pag">
        <section class="Info">
            <h1>¿Quien somos?</h1>
            <p>Lorem ipsum dolor sit amet consectetur, adipiscing elit ut fringilla, natoque vitae dictumst non. Inceptos gravida mus nascetur nisi lobortis quis nam, a fusce curabitur ridiculus sapien primis augue scelerisque, ultrices torquent neque massa conubia fringilla. Dictum nullam non imperdiet id volutpat sed nibh fames metus, taciti pellentesque velit rutrum habitasse class tristique ornare suspendisse, pharetra sem quam erat arcu massa dignissim vestibulum.<p>
        </section>
        </section>
        
        <br>
        
        <section class="Info-iz">
            <h1>¿Que vendemos?</h1>
            <p>Lorem ipsum dolor sit amet consectetur, adipiscing elit ut fringilla, natoque vitae dictumst non. Inceptos gravida mus nascetur nisi lobortis quis nam, a fusce curabitur ridiculus sapien primis augue scelerisque, ultrices torquent neque massa conubia fringilla. Dictum nullam non imperdiet id volutpat sed nibh fames metus, taciti pellentesque velit rutrum habitasse class tristique ornare suspendisse, pharetra sem quam erat arcu massa dignissim vestibulum.<p>
        </section>

        <br>
        <section class="color-pag">
        <section class="Info">
            <h1>¿Contactanos?</h1>
            <p>Lorem ipsum dolor sit amet consectetur, adipiscing elit ut fringilla, natoque vitae dictumst non. Inceptos gravida mus nascetur nisi lobortis quis nam, a fusce curabitur ridiculus sapien primis augue scelerisque, ultrices torquent neque massa conubia fringilla. Dictum nullam non imperdiet id volutpat sed nibh fames metus, taciti pellentesque velit rutrum habitasse class tristique ornare suspendisse, pharetra sem quam erat arcu massa dignissim vestibulum.<p>
        </section>
        </section>

        
            
        <h1>Productos<br> </h1>
            <section class="cards-section">
            <div class="card">
            <h2>p1</h2>
        <p>Descripción.</p>
        </div>

        <div class="card">
            <h2>p2</h2>
            <p>Descripción.</p>
        </div>
        <div class="card">
        <h2>p2</h2>
        <p>Descripción </p>
    </div>
</section>

        <section class="footer-section">
            <p>&copy; 2025 Diamante Azul. Todos los derechos reservados.</p>
        </section>
    </main>
</body>
</html>
